package com.apkconverter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> androidx.compose.foundation.isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= 31) { if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx) }
    else if (dark) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun fmt(b: Long) = when {
    b > 1 shl 30 -> "%.2f Go".format(b / 1073741824.0)
    b > 1 shl 20 -> "%.1f Mo".format(b / 1048576.0)
    else -> "${b / 1024} Ko"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: MainVm) {
    val tabs = listOf("Convertir", "Fichiers", "Historique", "Réglages")
    Scaffold(
        topBar = { TopAppBar(title = { Text("APK Converter") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = vm.tab == i, onClick = { vm.tab = i }, icon = {}, label = { Text(t) }, alwaysShowLabel = true)
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (vm.tab) {
                0 -> ConvertScreen(vm)
                1 -> BrowserScreen(vm)
                2 -> HistoryScreen()
                else -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
fun ConvertScreen(vm: MainVm) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { vm.loadUri(it) } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
                Text("Choisir un fichier (APKS, APKM, XAPK, ZIP)")
            }
        }
        if (vm.busy) item { LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth()) }
        if (vm.msg.isNotBlank()) item { Text(vm.msg, style = MaterialTheme.typography.bodyMedium) }
        if (vm.source != null) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(vm.info.name.ifBlank { vm.srcName }, style = MaterialTheme.typography.titleMedium)
                        Text("Format : ${vm.info.format}")
                        if (vm.info.pkg.isNotBlank()) Text("Package : ${vm.info.pkg}")
                        if (vm.info.version.isNotBlank()) Text("Version : ${vm.info.version}")
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.selectAll(true) }) { Text("Tout") }
                    OutlinedButton(onClick = { vm.selectAuto() }) { Text("Auto (appareil)") }
                    OutlinedButton(onClick = { vm.selectAll(false) }) { Text("Base seule") }
                }
            }
            itemsIndexed(vm.items) { i, it ->
                Row(Modifier.fillMaxWidth().clickable { vm.toggle(i) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = it.selected, onCheckedChange = { vm.toggle(i) })
                    Column {
                        Text(it.entry.substringAfterLast('/'))
                        Text("${it.kind.uppercase()} • ${fmt(it.size)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.run(Mode.BASE) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) { Text("Extraire base.apk") }
                    Button(onClick = { vm.run(Mode.SELECTED) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) { Text("Extraire la sélection") }
                    FilledTonalButton(onClick = { vm.run(Mode.INSTALL) }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) { Text("Installer la sélection (splits)") }
                }
            }
        }
    }
}

@Composable
fun BrowserScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val granted = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
    if (!granted) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("L'accès à tous les fichiers est nécessaire pour parcourir le stockage.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Autoriser l'accès") }
        }
        return
    }
    var dir by remember { mutableStateOf(Environment.getExternalStorageDirectory()) }
    var onlyPk by remember { mutableStateOf(true) }
    val exts = setOf("apk", "apks", "apkm", "xapk", "zip")
    val list = remember(dir, onlyPk) {
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { it.isDirectory || !onlyPk || it.extension.lowercase() in exts }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { dir.parentFile?.let { dir = it } }, enabled = dir.parentFile != null) { Text("↑ Parent") }
            Text(dir.absolutePath, Modifier.weight(1f), maxLines = 1, style = MaterialTheme.typography.bodySmall)
            Switch(checked = onlyPk, onCheckedChange = { onlyPk = it })
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list) { f ->
                ListItem(
                    headlineContent = { Text((if (f.isDirectory) "📁 " else "📦 ") + f.name) },
                    supportingContent = { if (f.isFile) Text(fmt(f.length())) },
                    modifier = Modifier.clickable { if (f.isDirectory) dir = f else vm.loadFile(f) }
                )
            }
        }
    }
}

@Composable
fun HistoryScreen() {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(Engine.history(ctx)) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedButton(onClick = { Engine.clearHistory(ctx); list = emptyList() }) { Text("Vider l'historique") }
        LazyColumn {
            items(list) { r ->
                ListItem(
                    headlineContent = { Text(r.getOrElse(1) { "" }) },
                    supportingContent = { Text("${r.getOrElse(0) { "" }} • ${r.getOrElse(2) { "" }}\n${r.getOrElse(3) { "" }}") }
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainVm) {
    val s by vm.settings.collectAsState()
    @Composable
    fun sw(label: String, v: Boolean, on: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f)); Switch(checked = v, onCheckedChange = on)
        }
    }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        var out by remember(s.outDir) { mutableStateOf(s.outDir) }
        OutlinedTextField(out, { out = it }, label = { Text("Dossier de sortie") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { vm.saveSettings(s.copy(outDir = out)) }) { Text("Enregistrer le dossier") }
        sw("Sélection auto (ABI, densité, langue)", s.auto) { vm.saveSettings(s.copy(auto = it)) }
        sw("Copier les fichiers OBB (XAPK)", s.obb) { vm.saveSettings(s.copy(obb = it)) }
        sw("Écraser les fichiers existants", s.overwrite) { vm.saveSettings(s.copy(overwrite = it)) }
        sw("Supprimer la source après conversion (fichiers parcourus)", s.deleteSrc) { vm.saveSettings(s.copy(deleteSrc = it)) }
        Text("Thème")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Système", "Clair", "Sombre").forEachIndexed { i, t ->
                FilterChip(selected = s.theme == i, onClick = { vm.saveSettings(s.copy(theme = i)) }, label = { Text(t) })
            }
        }
    }
}
