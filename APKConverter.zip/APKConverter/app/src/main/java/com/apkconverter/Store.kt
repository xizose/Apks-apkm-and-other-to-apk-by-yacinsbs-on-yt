package com.apkconverter

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

val Context.ds by preferencesDataStore("settings")

data class Settings(
    val outDir: String = "/storage/emulated/0/APK Converter",
    val auto: Boolean = true,
    val deleteSrc: Boolean = false,
    val obb: Boolean = true,
    val overwrite: Boolean = false,
    val theme: Int = 0,
)

private val kOut = stringPreferencesKey("out")
private val kAuto = booleanPreferencesKey("auto")
private val kDel = booleanPreferencesKey("del")
private val kObb = booleanPreferencesKey("obb")
private val kOver = booleanPreferencesKey("over")
private val kTheme = intPreferencesKey("theme")

class SettingsStore(private val c: Context) {
    val flow = c.ds.data.map { p ->
        val d = Settings()
        Settings(p[kOut] ?: d.outDir, p[kAuto] ?: d.auto, p[kDel] ?: d.deleteSrc,
            p[kObb] ?: d.obb, p[kOver] ?: d.overwrite, p[kTheme] ?: d.theme)
    }
    suspend fun save(s: Settings) {
        c.ds.edit {
            it[kOut] = s.outDir; it[kAuto] = s.auto; it[kDel] = s.deleteSrc
            it[kObb] = s.obb; it[kOver] = s.overwrite; it[kTheme] = s.theme
        }
    }
}
