package com.apkconverter

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainVm(private val app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    val settings = store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    var source by mutableStateOf<File?>(null)
    var origin by mutableStateOf<File?>(null)
    var srcName by mutableStateOf("")
    var info by mutableStateOf(PkgInfo())
    val items = mutableStateListOf<Item>()
    var busy by mutableStateOf(false)
    var progress by mutableStateOf(0f)
    var msg by mutableStateOf("")
    var tab by mutableStateOf(0)

    fun saveSettings(s: Settings) { viewModelScope.launch { store.save(s) } }

    fun loadUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            busy = true; msg = "Lecture du fichier…"
            try {
                var name = "fichier.apks"
                app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && i >= 0) name = c.getString(i)
                }
                val tmp = File(app.cacheDir, "in.zip")
                app.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                origin = null
                apply(tmp, name)
            } catch (e: Exception) { msg = "Erreur : ${e.message}" } finally { busy = false }
        }
    }

    fun loadFile(f: File) {
        viewModelScope.launch(Dispatchers.IO) {
            busy = true; msg = "Lecture du fichier…"
            try { origin = f; apply(f, f.name) } catch (e: Exception) { msg = "Erreur : ${e.message}" } finally { busy = false }
        }
    }

    private suspend fun apply(f: File, name: String) {
        val (i, list) = Engine.scan(f, name, app, settings.value.auto)
        withContext(Dispatchers.Main) {
            source = f; srcName = name; info = i
            items.clear(); items.addAll(list)
            msg = if (list.isEmpty()) "Aucun APK trouvé dans cette archive" else "${list.size} APK trouvés"
            tab = 0
        }
    }

    fun toggle(i: Int) { items[i] = items[i].copy(selected = !items[i].selected) }
    fun selectAll(v: Boolean) { items.indices.forEach { items[it] = items[it].copy(selected = v || items[it].kind == "base") } }
    fun selectAuto() {
        val src = source ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val (_, l) = Engine.scan(src, srcName, app, true)
            withContext(Dispatchers.Main) { items.clear(); items.addAll(l) }
        }
    }

    fun run(mode: Mode) {
        val f = source ?: return
        val s = settings.value
        viewModelScope.launch(Dispatchers.IO) {
            busy = true; progress = 0f
            try {
                val sel = if (mode == Mode.BASE) items.filter { it.kind == "base" }.take(1) else items.filter { it.selected }
                if (sel.isEmpty()) { msg = "Aucun APK sélectionné"; return@launch }
                val label = Engine.safe(info.name.ifBlank { srcName.substringBeforeLast('.') })
                if (mode == Mode.INSTALL) {
                    val tmp = File(app.cacheDir, "inst").apply { deleteRecursively(); mkdirs() }
                    val files = Engine.extract(f, sel, tmp, true, label, info.version) { p, n -> progress = p; msg = n }
                    withContext(Dispatchers.Main) { Engine.install(app, files) }
                    msg = "Installation lancée (${files.size} APK)"
                    Engine.addHistory(app, srcName, mode, "installation")
                } else {
                    val out = Engine.outDir(s.outDir, app)
                    val files = Engine.extract(f, sel, out, s.overwrite, label, info.version) { p, n -> progress = p; msg = n }
                    var extra = ""
                    if (s.obb) { val n = Engine.copyObb(f); if (n > 0) extra = " + $n OBB" }
                    msg = "Terminé : ${files.size} APK$extra → ${out.absolutePath}"
                    Engine.addHistory(app, srcName, mode, out.absolutePath)
                    if (s.deleteSrc) origin?.let { runCatching { it.delete() } }
                }
            } catch (e: Exception) { msg = "Erreur : ${e.message}" } finally { busy = false }
        }
    }
}
