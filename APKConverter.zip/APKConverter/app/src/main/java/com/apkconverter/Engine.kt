package com.apkconverter

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipFile

enum class Mode { BASE, SELECTED, INSTALL }

data class PkgInfo(val name: String = "", val pkg: String = "", val version: String = "", val format: String = "")
data class Item(val entry: String, val size: Long, val kind: String, val token: String, val selected: Boolean)

object Engine {
    private val DENS = listOf("ldpi", "mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi")

    fun safe(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "app" }

    fun scan(f: File, origName: String, ctx: Context, auto: Boolean): Pair<PkgInfo, List<Item>> {
        ZipFile(f).use { z ->
            var info = PkgInfo(format = origName.substringAfterLast('.', "zip").uppercase())
            z.getEntry("manifest.json")?.let {
                runCatching {
                    val j = JSONObject(z.getInputStream(it).bufferedReader().readText())
                    info = PkgInfo(j.optString("name"), j.optString("package_name"), j.optString("version_name"), "XAPK")
                }
            }
            z.getEntry("info.json")?.let {
                runCatching {
                    val j = JSONObject(z.getInputStream(it).bufferedReader().readText())
                    info = PkgInfo(j.optString("app_name"), j.optString("pname"), j.optString("versionname"), "APKM")
                }
            }
            val apks = z.entries().asSequence().filter { !it.isDirectory && it.name.endsWith(".apk", true) }.toList()
            val raw = apks.map { e ->
                val n = e.name.substringAfterLast('/')
                val isCfg = n.startsWith("split_config.") || n.startsWith("config.")
                val tok = if (isCfg) n.removeSuffix(".apk").removePrefix("split_").removePrefix("config.") else ""
                val kind = when {
                    !isCfg -> if (n.startsWith("split_")) "other" else "base"
                    tok in listOf("arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64", "mips") -> "abi"
                    tok in DENS || tok == "tvdpi" || tok == "nodpi" -> "dpi"
                    tok.length in 2..7 && tok.all { it.isLowerCase() || it == '_' } -> "lang"
                    else -> "other"
                }
                Item(e.name, e.size, kind, tok, true)
            }
            val abi = Build.SUPPORTED_ABIS.map { it.replace('-', '_') }.firstOrNull { a -> raw.any { it.kind == "abi" && it.token == a } }
            val dm = ctx.resources.displayMetrics.densityDpi
            val dens = when { dm <= 120 -> "ldpi"; dm <= 160 -> "mdpi"; dm <= 240 -> "hdpi"; dm <= 320 -> "xhdpi"; dm <= 480 -> "xxhdpi"; else -> "xxxhdpi" }
            val lang = Locale.getDefault().language
            val items = raw.map {
                val sel = if (!auto) true else when (it.kind) {
                    "abi" -> it.token == abi
                    "dpi" -> it.token == dens
                    "lang" -> it.token == lang || it.token == "en"
                    else -> true
                }
                it.copy(selected = sel)
            }
            return info to items
        }
    }

    private fun unique(f: File, overwrite: Boolean): File {
        if (overwrite || !f.exists()) return f
        var i = 1
        while (true) {
            val c = File(f.parentFile, "${f.nameWithoutExtension} ($i).${f.extension}")
            if (!c.exists()) return c
            i++
        }
    }

    fun outDir(path: String, ctx: Context): File {
        val d = File(path)
        return if ((d.exists() || d.mkdirs()) && d.canWrite()) d
        else File(ctx.getExternalFilesDir(null), "converted").apply { mkdirs() }
    }

    fun extract(src: File, items: List<Item>, out: File, overwrite: Boolean, label: String, version: String,
                onProgress: (Float, String) -> Unit): List<File> {
        val result = mutableListOf<File>()
        ZipFile(src).use { z ->
            val single = items.size == 1
            val dir = if (single) out else File(out, label).also { it.mkdirs() }
            items.forEachIndexed { i, it ->
                val e = z.getEntry(it.entry) ?: return@forEachIndexed
                val name = if (single) safe(label + if (version.isNotBlank()) "_$version" else "") + ".apk"
                else it.entry.substringAfterLast('/')
                val dest = unique(File(dir, name), overwrite)
                onProgress(i.toFloat() / items.size, name)
                z.getInputStream(e).use { inp -> dest.outputStream().use { o -> inp.copyTo(o, 64 * 1024) } }
                result += dest
            }
        }
        onProgress(1f, "OK")
        return result
    }

    fun copyObb(src: File): Int {
        var n = 0
        ZipFile(src).use { z ->
            z.entries().asSequence().filter { !it.isDirectory && it.name.startsWith("Android/obb/") }.forEach {
                runCatching {
                    val d = File(Environment.getExternalStorageDirectory(), it.name)
                    d.parentFile?.mkdirs()
                    z.getInputStream(it).use { i -> d.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                    n++
                }
            }
        }
        return n
    }

    fun install(ctx: Context, files: List<File>) {
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            files.forEach { f ->
                f.inputStream().use { i -> s.openWrite(f.name, 0, f.length()).use { o -> i.copyTo(o, 64 * 1024); s.fsync(o) } }
            }
            val pend = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallReceiver::class.java),
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            s.commit(pend.intentSender)
        }
    }

    private fun hist(ctx: Context) = File(ctx.filesDir, "history.txt")
    fun addHistory(ctx: Context, name: String, mode: Mode, path: String) {
        val t = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        hist(ctx).appendText("$t|$name|$mode|$path\n")
    }
    fun history(ctx: Context): List<List<String>> =
        hist(ctx).takeIf { it.exists() }?.readLines()?.reversed()?.map { it.split("|") } ?: emptyList()
    fun clearHistory(ctx: Context) { hist(ctx).delete() }
}
