# APK Converter
App Android (Kotlin + Jetpack Compose) : APKS / APKM / XAPK -> APK.
- Extraire base.apk ou une sélection de splits (auto : ABI, densité, langue)
- Installer les splits via PackageInstaller
- Navigateur de fichiers (accès complet au stockage), historique, réglages
- Copie des OBB (XAPK)
Build : push sur GitHub, l'onglet Actions produit l'APK. Tags `v*` = release signée (secrets KEYSTORE_BASE64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD).
